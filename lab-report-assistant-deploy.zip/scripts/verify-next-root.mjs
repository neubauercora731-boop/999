import { existsSync, readdirSync } from "node:fs";
import { join } from "node:path";

const cwd = process.cwd();
const entries = readdirSync(cwd, { withFileTypes: true })
  .map((entry) => `${entry.isDirectory() ? "[dir] " : "[file]"}${entry.name}`)
  .sort();

const candidates = ["app", "src/app", "pages", "src/pages"];
const existing = candidates.filter((candidate) => existsSync(join(cwd, candidate)));

console.log("[prebuild] cwd:", cwd);
console.log("[prebuild] root entries:", entries.join(", "));
console.log("[prebuild] route dirs found:", existing.length ? existing.join(", ") : "none");

if (existing.length === 0) {
  console.error(
    "[prebuild] Next.js cannot find app/pages in the current build directory. " +
      "Set the platform project root to the folder that contains package.json and app/.",
  );
  process.exit(1);
}

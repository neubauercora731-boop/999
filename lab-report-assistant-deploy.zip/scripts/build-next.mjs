import { spawnSync } from "node:child_process";
import { existsSync, readdirSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const scriptDir = dirname(fileURLToPath(import.meta.url));
const projectRoot = resolve(scriptDir, "..");
const routeCandidates = ["app", "src/app", "pages", "src/pages"];
const existingRouteDirs = routeCandidates.filter((candidate) =>
  existsSync(join(projectRoot, candidate)),
);

const rootEntries = readdirSync(projectRoot, { withFileTypes: true })
  .map((entry) => `${entry.isDirectory() ? "[dir] " : "[file]"}${entry.name}`)
  .sort();

console.log("[build] cwd:", process.cwd());
console.log("[build] project root:", projectRoot);
console.log("[build] project root entries:", rootEntries.join(", "));
console.log(
  "[build] route dirs found:",
  existingRouteDirs.length ? existingRouteDirs.join(", ") : "none",
);

if (existingRouteDirs.length === 0) {
  console.error(
    "[build] Next.js cannot find app/pages beside package.json. " +
      "The uploaded files are incomplete or the project root is wrong.",
  );
  process.exit(1);
}

const nextBin = join(projectRoot, "node_modules", "next", "dist", "bin", "next");

if (!existsSync(nextBin)) {
  console.error("[build] Missing local Next.js binary. Run npm ci before building.");
  process.exit(1);
}

const result = spawnSync(process.execPath, [nextBin, "build", projectRoot], {
  cwd: projectRoot,
  env: process.env,
  stdio: "inherit",
});

process.exit(result.status ?? 1);
